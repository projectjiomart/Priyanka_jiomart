package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Editaccount 
{
	static WebElement element;
	
	
	public static WebElement ClickonArrow (WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/div/div[1]"));
		return element;
	}
	public static WebElement ClickOnAccount (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"hmenu-top-section\"]/ul/li[1]/a"));
		return element;
	}
	public static WebElement SigninMobNm (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"loginfirst_mobileno\"]")).sendKeys("9075904995");
		return element;
	}
	public static WebElement Continue1(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/div[1]/form/div[2]/button[1]"));
		return element;
	}
	public static WebElement Verify (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div/div[2]/div[1]/form/div[2]/div[1]/button"));
		return element;
	}
	public static WebElement EditAccount(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-account/div[1]/div[2]/div[2]/div/div[1]/a"));
		return element;
	}
	public static WebElement FirstNm (WebDriver driver)  ///html/body/app-root/app-layout/div/main/div/app-account/div[3]/div/form/div/div[2]/div/div[1]/mat-form-field/div/div[1]/div/input
	{
		////*[@id="firstname"]
		element=driver.findElement(By.xpath("//*[@id=\"firstname\"]"));
		return element;
	}
	public static WebElement LastNm (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"lastname\"]"));
		return element;
		////*[@id="lastname"]
	}
	public static WebElement ClickBrithOpenCaldClick (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"frameModalTop\"]/div/form/div/div[2]/div/div[3]/div[2]/mat-form-field/div/div[1]/div[2]/mat-datepicker-toggle/button"));
		return element;
	} 
	////*[@id="mat-datepicker-0"]/mat-calendar-header/div/div/button[1]/span[1]/div
	public static WebElement ClickArrowmonth(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]/span[1]/div"));
		return element;
	}
	public static WebElement ClickYear (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-multi-year-view/table/tbody/tr[5]/td[3]/div[1]")).sendKeys("1999");
		return element;
	}
	public static WebElement ClickMonth (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-year-view/table/tbody/tr[4]/td[2]/div[1]")).sendKeys("Nove");
		return element;
	}
	public static WebElement ClickDate (WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-month-view/table/tbody/tr[2]/td[5]/div[1]")).sendKeys("7");
		return element;
	}
	
	public static WebElement SaveAndChange (WebDriver driver)
	{
		////*[@id="frameModalTop"]/div/form/div/div[2]/div/div[6]/button
		element=driver.findElement(By.xpath("//*[@id=\"frameModalTop\"]/div/form/div/div[2]/div/div[6]/button"));
		return element;
	}
}

////*[@id="frameModalTop"]/div/form/div/div[2]/div/div[3]/div[2]/mat-form-field/div/div[1]/div[2]/mat-datepicker-toggle/button/span[1]/svg
////*[@id="mat-datepicker-0"]/mat-calendar-header/div/div/button[1]/span[1]/div
/////////*[@id="mat-datepicker-0"]/div/mat-year-view/table/tbody/tr[4]/td[3]
////*[@id="mat-datepicker-0"]/div/mat-month-view/table/tbody/tr[4]/td[4]/div[1]












