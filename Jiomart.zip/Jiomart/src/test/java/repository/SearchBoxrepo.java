package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchBoxrepo 
{
	static WebElement element;
	
	public static WebElement Searchbox (WebDriver driver)  
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_list_btn\"]"));
		return element;
	}
	public static WebElement ProductName (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_val\"]"));
		return element;
	}
	public static WebElement SerchBt (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_form\"]/button[2]"));
		return element;
	}
	
	public static WebElement Range (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"sort_container\"]/button[3]"));
		return element;
	}
	

}
