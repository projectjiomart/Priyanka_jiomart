package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignUpRepo 
{
static WebElement element;
	
	public static WebElement SignUp (WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/div/div[5]/div/a[1]"));
		return element;
	}
	public static WebElement Entermob(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"loginfirst_mobileno\"]"));
		return element;
	}
	public static WebElement Continue(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/div[1]/form/div[2]/button[1]"));
		return element;
	}
	public static WebElement Firstname1(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"reg_firstname\"]"));
		return element;
	}
	public static WebElement Enterlastname(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"reg_lastname\"]"));
		return element;
	}
	public static WebElement EnteremailId(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"reg_email\"]"));
		return element;
	}
	public static WebElement Enterpassword (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"register_pwd\"]"));
		return element;
	}
	public static WebElement Enterconfirmpass (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"register_confirm_pwd\"]"));
		return element;
	}
	public static WebElement Verify (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/form/div[6]/div/button"));
		return element;
	}
	
}



