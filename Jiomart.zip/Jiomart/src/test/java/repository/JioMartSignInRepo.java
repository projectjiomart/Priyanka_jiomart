package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JioMartSignInRepo 
{
	static WebElement element;
	
	public static WebElement SignIn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/div/div[5]/div/a[1]"));
		return element;
	}
	public static WebElement EnterMob(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"loginfirst_mobileno\"]"));
		return element;
	}
	public static WebElement Continue(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/div[1]/form/div[2]/button[1]"));
		return element;
	}
	public static WebElement Verify(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div/div[2]/div[1]/form/div[2]/div[1]/button"));
		return element;
	}
	
	
	
}
