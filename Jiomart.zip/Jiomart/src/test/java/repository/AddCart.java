package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddCart 
{
static WebElement element;

	
	public static WebElement Search(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_list_btn\"]"));
		return element;
	}
	public static WebElement Searchproduct(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"rel_search_val\"]")).sendKeys("oil");
		return element;
	}
	public static WebElement SearchNow(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_form\"]/button[2]"));
		return element;
	}
	public static WebElement ClickOnprodcutAddcartbutn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"hits\"]/div/div/ol/li[8]/div/div[1]/button"));
		return element;
	}
	public static WebElement ClickOnAddToCart(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"minicart_btn\"]/a")); 
		return element;
	}
	
	public static WebElement ClickOnPlaceOrder(WebDriver driver) 
	{
		///html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[4]/div[2]/div[2]/button
		
		element=driver.findElement(By.xpath("//button[contains(text(),'Place Order')]"));
		return element;                    ///html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[5]/div[2]/div[2]/button
	}
	public static WebElement SigninpageEnterMob(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"loginfirst_mobileno\"]")).sendKeys("9503089085"); 
		return element;
	}
	public static WebElement ClickContinue(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/div[1]/form/div[2]/button[1]")); 
		return element;
	}
	
	public static WebElement Verify(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div/div[2]/div[1]/form/div[2]/div[1]/button")); 
		return element;
	}
	public static WebElement ClickPlaceOrder2(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[5]/div[2]/div[2]/button")); 
		return element;                  //  /html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[5]/div[2]/div[2]/button
	}
	public static WebElement ClickOnTypeAdd (WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressmodal\"]/div/div/div[2]/div/div[5]"));
		return element;
	}
	public static WebElement PinCode(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"pin\"]"));
		return element;
	}
	public static WebElement BuildingName (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"building_name1\"]"));
		return element;
	}
	public static WebElement Address(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"building_address\"]"));
		return element;
	}
	public static WebElement Area(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"area_name\"]"));
		return element;
	}
	public static WebElement City(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-review/div[30]/div/form/div/div[2]/div[1]/div[1]/div[10]/input"));
		return element;
	}
	public static WebElement EnterName (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressee_name\"]"));
		return element;
	}
	public static WebElement EnterMobileNumber (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"mobile_no\"]"));
		return element;
	}
	public static WebElement SaveAshomeclick(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressformmodal\"]/div/form/div/div[2]/div[1]/div[3]/ul/li[1]/label"));
		return element;
	}
	public static WebElement ClickOnSaveAdd(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressformmodal\"]/div/form/div/div[2]/div[2]/button"));
		return element;
	}
	public static WebElement ChangeOrAddAddress(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-review/div[1]/div/div[1]/div[1]/div/div[2]/button")); 
		return element;
	}
	public static WebElement ClickEdit(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressmodal\"]/div/div/div[2]/div[2]/div[2]/div/div[2]/div[2]/div/button"));
		return element;
	}
	
}
