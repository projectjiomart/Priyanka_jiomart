package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentRepo 
{
	static WebElement element;
	public static WebElement Search1(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_list_btn\"]"));
		return element;
	}
	public static WebElement Search_product(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"rel_search_val\"]")).sendKeys("oil");
		return element;
	}
	public static WebElement ClickSearchNow(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"rel_search_form\"]/button[2]"));
		return element;
	}
	public static WebElement ClickOnprodcutAddcartbutn1(WebDriver driver) ////*[@id="hits"]/div/div/ol/li[3]/div/div[1]/button
	{
		element=driver.findElement(By.xpath("//*[@id=\"hits\"]/div/div/ol/li[12]/div/div[1]/button")); ////*[@id="hits"]/div/div/ol/li[12]/div/div[1]/button
		return element;
	}
	public static WebElement ClickAddToCart(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"minicart_btn\"]/a/div/span")); ////*[@id="minicart_btn"]/a/div/span
		return element;
	}
	
	public static WebElement ClickPlaceOrder1(WebDriver driver) 
	{
		
		
		element=driver.findElement(By.xpath("//button[contains(text(),'Place Order')]"));
		return element;                    ///html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[5]/div[2]/div[2]/button
	}
	public static WebElement SignInpageEnterMob(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"loginfirst_mobileno\"]")).sendKeys("9527457227"); 
		return element;
	}
	public static WebElement ClickContinuebtn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div[1]/div[2]/div/div[1]/form/div[2]/button[1]")); 
		return element;
	}
	
	public static WebElement ClickVerify(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"app\"]/main/div/app-login/div[1]/div/div/div[2]/div[1]/form/div[2]/div[1]/button")); 
		return element;
	}
	
	public static WebElement ClickOnTypeAdd(WebDriver driver) 
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressmodal\"]/div/div/div[2]/div/div[5]"));
		return element;
	}
	public static WebElement EnterPinCode(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"pin\"]"));
		return element;
	}
	public static WebElement EnterBuildingName (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"building_name1\"]"));
		return element;
	}
	public static WebElement EnterAddress(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"building_address\"]"));
		return element;
	}
	public static WebElement EnterArea(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"area_name\"]"));
		return element;
	}
	public static WebElement EnterCity(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-review/div[30]/div/form/div/div[2]/div[1]/div[1]/div[10]/input"));
		return element;
	}
	public static WebElement EnterNm(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressee_name\"]"));
		return element;
	}
	public static WebElement EnterMobileNm (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"mobile_no\"]"));
		return element;
	}
	public static WebElement ClickSaveAshome(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressformmodal\"]/div/form/div/div[2]/div[1]/div[3]/ul/li[1]/label"));
		return element;
	}
	public static WebElement ClickOnSaveAddbtn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"addressformmodal\"]/div/form/div/div[2]/div[2]/button"));
		return element;
	}
	public static WebElement ClickOnMakePayment(WebDriver driver) ////*[@id="app"]/main/div/app-review/div[1]/div/div[2]/div/div[4]/div[2]/button
	{
		element=driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-review/div[1]/div/div[2]/div/div[4]/div[2]/button"));
		return element;
	}
	public static WebElement ClickOnDebit(WebDriver driver)  //Scrolling
	{
		///html/body/div/div[2]/div/div/div[3]/div[1]/div[1]/div/div[2]/div
		element=driver.findElement(By.xpath("//*[@id=\"2\"]"));
		return element;
	}
	public static WebElement EnterCardNUmber(WebDriver driver) ////*[@id="cardNumber"]
	{
		element=driver.findElement(By.xpath("//*[@id=\"cardNumber\"]"));
		return element;
	}
	public static WebElement ClickOnExpriedate(WebDriver driver)
	      ////*[@id="__next"]/div[3]/div/div/div[2]/div/div[2]/button[1]/div[1]/p
	{
		element=driver.findElement(By.xpath("//*[contains(text(),'css-snkbx3')]"));
		return element;
		////*[@id="__next"]/div[3]/div/div/div[2]/div/div[2]/button[1]/div[2]/img
		///html/body/div/div[3]/div/div/div[2]/div/div[2]/button[1]/div[1]
		 ////*[@id="__next"]/div[3]/div/div/div[2]/div/div[2]/button[1]/div[1]/p
	}
	public static WebElement ClickOnexpriemonth(WebDriver driver)
	{
		element=driver.findElement(By.xpath("[@id=\"__next\"]/div[3]/div/div/div[2]/div/div[2]/button[2]/div[2]/img"));
		return element; ////*[@id="__next"]/div[3]/div/div/div[2]/div/div[2]/button[2]/div[2]/img
	}
	public static WebElement ClickOnCCV(WebDriver driver) ////*[@id="cvvNumber"]
	{
		element=driver.findElement(By.xpath("//*[@id=\"cvvNumber\"]"));
		return element;
	}
	public static WebElement EnterName2(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cardHolderName\"]"));
		return element;
	}
	
	public static WebElement ClickPaybtn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[3]/div/div/div[3]/button"));
		return element;
	}
	////*[@id="__next"]/div[3]/div/div/div[1]/div/img
	public static WebElement Closearrow(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[3]/div/div/div[1]/div/img"));
		return element;
	}
}



//PaymentRepo.ClickOnprodcutAddcartbutn1(driver).click();
//PaymentRepo
