package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.JioMartSignInRepo;

public class SignInstepDefns 
{
	 WebDriver driver;
	@Given("edge browser is open")
	public void edge_browser_is_open() 
	{
	   WebDriverManager.edgedriver().setup();
	   driver=new EdgeDriver();
	   driver.manage().window().maximize();
	}

	@Given("user is on the SignIn page")
	public void user_is_on_the_sign_in_page() throws InterruptedException 
	{
	   driver.get("https://www.jiomart.com/");
	   Thread.sleep(2000);
	   JioMartSignInRepo.SignIn(driver).click();
	   Thread.sleep(2000);
	}
	   
	  @When("^user enters (.*) In mobile number filed$")
	  public void user_enters_mobile_number(String mobilenumber) throws InterruptedException 
	   {
		   JioMartSignInRepo.EnterMob(driver).sendKeys(mobilenumber);
		   Thread.sleep(2000);
		   JioMartSignInRepo.Continue(driver).click();
		   Thread.sleep(20000);  
	   }
	@Given("hits the Continue  button")
	public void hits_the_continue_button() 
	{
		try
		{
			JioMartSignInRepo.Verify(driver).click();
			System.out.println("valid mobile number");
		}
	    catch (Exception e)
	    {
	    	System.out.println("Invalid mobile number");
	    	
	    }
	}

	@Then("the user gets navigated to Shopping page")
	public void the_user_gets_navigated_to_shopping_page() 
	{
		System.out.println("navigated to Shopping page");
		   
		
	}
}
