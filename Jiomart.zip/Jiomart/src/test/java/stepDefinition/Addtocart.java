package stepDefinition;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AddCart;

public class Addtocart
{
	 WebDriver driver;
	@Given("User is on Home page")
	public void user_is_on_home_page() 
	{
		 WebDriverManager.edgedriver().setup();
		   driver=new EdgeDriver();
		   driver.manage().window().maximize();
	    
	}

	@When("User Search the product")
	public void user_search_the_product() throws Exception 
	{
		 driver.get("https://www.jiomart.com/");
		 Thread.sleep(2000);
		 AddCart.Search(driver).click();
		 AddCart.Searchproduct(driver);
		 AddCart.SearchNow(driver).click();
		 
		 
		 
	}

	@And("User is Add the product in add cart")
	public void user_is_add_the_product_in_add_cart() throws InterruptedException 
	{
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(3000);
		AddCart.ClickOnprodcutAddcartbutn(driver).click();
		Thread.sleep(2000);
		AddCart.ClickOnAddToCart(driver).click();
		Thread.sleep(3000);
		//System.out.println(driver.findElement(By.xpath("/html/body/app-root/app-layout/div/main/div/app-shopping-cart/div[1]/div/div/div[2]/div[3]/div/h5")).getText());
		AddCart.ClickOnPlaceOrder(driver).click();
		Thread.sleep(1000);
		AddCart.SigninpageEnterMob(driver);
		Thread.sleep(2000);
		AddCart.ClickContinue(driver).click();
		Thread.sleep(20000);
		AddCart.Verify(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		AddCart.ClickOnPlaceOrder(driver).click();
	    Thread.sleep(1000);
		
		 
	}

	@And("User filled the all data")
	public void user_filled_the_all_data() throws IOException, InterruptedException 
	{
		FileInputStream file=new FileInputStream("C:\\Users\\Hp\\Documents\\Automation testing\\Poi12\\Poi_34.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("Sheet2");
		
		int rowSize=s.getLastRowNum();
		System.out.println("Pincode and BuldingName and address and Area and name and MobileNumber "+rowSize);
		 driver.getWindowHandles();
		 
		for(int i=1; i<=rowSize; i++)
		  {
			//int Pincode=(int) s.getRow(i).getCell(0).getNumericCellValue();
			 String Pincode=s.getRow(i).getCell(0).getStringCellValue();
			  String BuildingName=s.getRow(i).getCell(1).getStringCellValue();
			  String Address=s.getRow(i).getCell(2).getStringCellValue();
			  String Area=s.getRow(i).getCell(3).getStringCellValue();
			  String City=s.getRow(i).getCell(4).getStringCellValue();
			  String Name=s.getRow(i).getCell(5).getStringCellValue();
			  String MobileNumber=s.getRow(i).getCell(6).getStringCellValue();
			  System.out.println(Pincode + " , "+ BuildingName +" , "+ Address+ " , "+ Area+ " , "+Name+ " ,"+City+", "+MobileNumber);
		 
		 AddCart.ClickOnTypeAdd(driver).click();  //city1
		 Thread.sleep(2000);
		 AddCart.PinCode(driver).sendKeys(Pincode);
		 AddCart.BuildingName(driver).sendKeys(BuildingName);
		 AddCart.Address(driver).sendKeys(Address);
		 AddCart.Area(driver).sendKeys(Area);
		 AddCart.City(driver).sendKeys(City);
		 AddCart.EnterName(driver).sendKeys(Name);
		 AddCart.EnterMobileNumber(driver).sendKeys(MobileNumber);
		 AddCart.SaveAshomeclick(driver).click();
		 AddCart.ClickOnSaveAdd(driver).click();
		 AddCart.ChangeOrAddAddress(driver).click();
		 AddCart.ClickEdit(driver).click();
		 if(driver.getTitle().equals("review Page"))
		  {
			  driver.navigate().back();
			  
			  System.out.println("valid data");
		      System.out.println("");
		  }
		// else 
		  //{
			  //System.out.println("invalid data");
		      //System.out.println("");
			 // driver.findElement(By.id("fdclose")).click();
		  //}/*
			  
		
		  }
	      
		  
		//AddCart.ChangeOrAddAddress(driver).click();
		//AddCart.ClickEdit(driver).click();
	    
	}
	
	@Then("user is navigated to My cart")
	public void user_is_navigated_to_my_cart() 
	{
	   System.out.println(" navigated to My cart");
	}
	
}
