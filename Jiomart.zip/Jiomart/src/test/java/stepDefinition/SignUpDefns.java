package stepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;
import repository.SignUpRepo;

public class SignUpDefns 
{
	WebDriver driver;
	@Given("brower is the open")
	public void brower_is_the_open() 
	{
		 WebDriverManager.edgedriver().setup();
		 driver=new EdgeDriver();
		 driver.manage().window().maximize();
		// assertEquals(driver.getTitle(), "jiomart.com");
		 System.out.println(driver.getTitle());
		 
	    
	}

	@Given("user is on signup page")
	public void user_is_on_signup_page() throws InterruptedException 
	{
		driver.get("https://www.jiomart.com/");
		Thread.sleep(2000);
		
		
	}

	@When("users enters valid details and clicks on verify button")
	public void users_enters_valid_details_and_clicks_on_verify_button() throws InterruptedException, IOException 
	{
		
		
		FileInputStream file=new FileInputStream("C:\\Users\\Hp\\Documents\\Automation testing\\Poi12\\Poi_34.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("Sheet1");
		
		int rowSize=s.getLastRowNum();
		System.out.println("No of MobNm and FirstName and LastName and EmailID and password and confirmpass "+rowSize);
		
		
		for(int i=2; i<=rowSize; i++)
		{
			SignUpRepo.SignUp(driver).click();
			Thread.sleep(2000);
			String MobNum=s.getRow(i).getCell(0).getStringCellValue();
			String FirstName=s.getRow(i).getCell(1).getStringCellValue();
			String LastName=s.getRow(i).getCell(2).getStringCellValue();
			String EmailID=s.getRow(i).getCell(3).getStringCellValue();
			String password=s.getRow(i).getCell(4).getStringCellValue();
			String confirmpass=s.getRow(i).getCell(5).getStringCellValue();
			
			System.out.println("mobNum:"+MobNum);
			System.out.println("firstname:"+FirstName);
			System.out.println("lastname:"+LastName);
			System.out.println("Emailid:"+LastName);
			System.out.println("password:"+password);
			System.out.println("confirmpass:"+confirmpass);		
			
		SignUpRepo.Entermob(driver).sendKeys(MobNum);
		
		SignUpRepo.Continue(driver).click();
		Thread.sleep(2000);
		SignUpRepo.Firstname1(driver).sendKeys(FirstName);
		SignUpRepo.Enterlastname(driver).sendKeys(LastName);
		SignUpRepo.EnteremailId(driver).sendKeys(EmailID);
		SignUpRepo.Enterpassword(driver).sendKeys(password);
		SignUpRepo.Enterconfirmpass(driver).sendKeys(confirmpass);
		Thread.sleep(2000);
		SignUpRepo.Verify(driver).click();
		Thread.sleep(3000);
		
		driver.navigate().back();
		
	
		try
		{
			System.out.println("Valid Signup successfull");
			System.out.println("");
			s.getRow(i).createCell(2).setCellValue("valid signup successfull");
		}
		catch (Exception e)
		{
			System.out.println("Invalid Signup unsuccessfull");
			System.out.println("");
			s.getRow(i).createCell(2).setCellValue("Invalid signup unsuccessfull");
			
		}
		
		
		
		///users enters (.*) valid mobileNm and EmailId and password information
	}
}
	

	

	@Then("the user is navigated to home page")
	public void the_user_is_navigated_to_home_page() 
	{
		System.out.println("navigated to home page");
		driver.close();
	}
	
	


}
