package stepDefinition;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Editaccount;
import repository.SignUpRepo;

public class EditAccount 
{
	WebDriver driver;
	@Given("browser is the open")
	public void browser_is_the_open() throws InterruptedException 
	{
		 WebDriverManager.edgedriver().setup();
		   driver=new EdgeDriver();
		   driver.manage().window().maximize();
		   driver.get("https://www.jiomart.com/");
		   Thread.sleep(2000);
	}

	@And("user is on Signin page")
	public void user_is_on_signin_page() throws InterruptedException 
	{
		Editaccount.ClickonArrow(driver).click();
		Thread.sleep(2000);
		Editaccount.ClickOnAccount(driver).click();
		Editaccount.SigninMobNm(driver);
		Editaccount.Continue1(driver).click();
		Thread.sleep(15000);
		Editaccount.Verify(driver).click();
		Thread.sleep(2000);
		Editaccount.EditAccount(driver).click();
	  
	}

	@When("user ented edit details")
	public void user_ented_edit_details() throws IOException, InterruptedException 
	{
		FileInputStream file=new FileInputStream("C:\\Users\\Hp\\Documents\\Automation testing\\Poi12\\Poi_34.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("EditAc");
		
		int rowSize=s.getLastRowNum();
		System.out.println("Firstnm and last name and  "+rowSize);
		
		for(int i=2; i<=rowSize; i++)
		{
			
			Editaccount.FirstNm(driver).clear();
			Thread.sleep(2000);
			Editaccount.LastNm(driver).clear();
			Thread.sleep(2000);
			String FirstNm=s.getRow(i).getCell(0).getStringCellValue();
			String LastName=s.getRow(i).getCell(1).getStringCellValue();
			//String Gender=s.getRow(i).getCell(2).getStringCellValue();
			
			//Editaccount.EditAccount(driver).click();
			Editaccount.FirstNm(driver).sendKeys(FirstNm);
			Editaccount.LastNm(driver).sendKeys(LastName);
			Editaccount.ClickBrithOpenCaldClick(driver).click();
			Editaccount.ClickArrowmonth(driver).click();
			Editaccount.ClickYear(driver).click();
			Editaccount.ClickMonth(driver).click();
			Editaccount.ClickDate(driver).click();
			Editaccount.SaveAndChange(driver).click();
		}
		
	    
		
	    
	}

	@Then("the user navigate to home page")
	public void the_user_navigate_to_home_page() 
	{
	    System.out.println(" navigate to home page");
	   
	}

	
}
