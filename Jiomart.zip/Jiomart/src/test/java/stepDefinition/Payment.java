package stepDefinition;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AddCart;
import repository.PaymentRepo;

public class Payment 
{
	WebDriver driver;
	@Given("User is on home page with url")
	public void user_is_on_home_page_with_url() throws InterruptedException 
	{
		WebDriverManager.edgedriver().setup();
	     driver=new EdgeDriver();
		  driver.manage().window().maximize();
		  driver.get("https://www.jiomart.com/");
		  Thread.sleep(2000);
	}

	@When("User is Search  product")
	public void user_is_search_product() throws InterruptedException 
	{
		 PaymentRepo.Search1(driver).click();
		 Thread.sleep(2000);
		 PaymentRepo.Search_product(driver);
		 Thread.sleep(2000);
		 PaymentRepo.ClickSearchNow(driver).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js=(JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,200)");
			Thread.sleep(3000);
		 PaymentRepo.ClickOnprodcutAddcartbutn1(driver).click();
		 
		 
	    
	}

	@When("User is select the product in add to cart")
	public void user_is_select_the_product_in_add_to_cart() throws InterruptedException 
	{
		PaymentRepo.ClickAddToCart(driver).click();
		Thread.sleep(2000);
		PaymentRepo.ClickPlaceOrder1(driver).click();
		Thread.sleep(3000);
		PaymentRepo.SignInpageEnterMob(driver);
		Thread.sleep(3000);
		PaymentRepo.ClickContinuebtn(driver).click();
		Thread.sleep(20000);
		PaymentRepo.ClickVerify(driver).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		PaymentRepo.ClickPlaceOrder1(driver).click();
	    Thread.sleep(1000);
		
	    
	    
	}

	@When("User fill  all data")
	public void user_fill_all_data() throws InterruptedException, IOException 
	{
		FileInputStream file=new FileInputStream("C:\\Users\\Hp\\Documents\\Automation testing\\Poi12\\Poi_34.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("payment");
		
		int rowSize=s.getLastRowNum();
		System.out.println("no of data"+rowSize);
		 driver.getWindowHandles();
		
		 
		 for(int i=1; i<=rowSize; i++)
		  {
			
			 String pincode=s.getRow(i).getCell(0).getStringCellValue();
			  String BuildingNm=s.getRow(i).getCell(1).getStringCellValue();
			  String address=s.getRow(i).getCell(2).getStringCellValue();
			  String area=s.getRow(i).getCell(3).getStringCellValue();
			  String city1=s.getRow(i).getCell(4).getStringCellValue();
			  String name=s.getRow(i).getCell(5).getStringCellValue();
			  String mobileNm=s.getRow(i).getCell(6).getStringCellValue();
			  String CardNm=s.getRow(i).getCell(7).getStringCellValue();
			  String date=s.getRow(i).getCell(8).getStringCellValue();
			  String month=s.getRow(i).getCell(9).getStringCellValue();
			  String CCVnm=s.getRow(i).getCell(10).getStringCellValue();
			  String Name2=s.getRow(i).getCell(11).getStringCellValue();
			  
			 System.out.println(pincode + " , "+ BuildingNm +" , "+ address+ " , "+ area+ " , "+city1+ " ,"+name+", "+mobileNm+" ,"+CardNm+", "+date+","+month+","+CCVnm+"."+Name2);
		 
		PaymentRepo.ClickOnTypeAdd(driver).click();
		Thread.sleep(2000);
		PaymentRepo.EnterPinCode(driver).sendKeys(pincode);
		PaymentRepo.EnterBuildingName(driver).sendKeys(BuildingNm);
		PaymentRepo.EnterAddress(driver).sendKeys(address);
		PaymentRepo.EnterArea(driver).sendKeys(area);
		PaymentRepo.EnterCity(driver).sendKeys(city1);
		PaymentRepo.EnterNm(driver).sendKeys(name);
		PaymentRepo.EnterMobileNm(driver).sendKeys(mobileNm);
		PaymentRepo.ClickSaveAshome(driver).click();
		PaymentRepo.ClickOnSaveAddbtn(driver).click();
		Thread.sleep(2000);
		PaymentRepo.ClickOnMakePayment(driver).click();
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		PaymentRepo.ClickOnDebit(driver).click();
		Thread.sleep(3000);
		PaymentRepo.EnterCardNUmber(driver).sendKeys(CardNm);
		Thread.sleep(3000);
		PaymentRepo.ClickOnExpriedate(driver).sendKeys(date);
		Thread.sleep(2000);
		PaymentRepo.ClickOnexpriemonth(driver).sendKeys(month);
		Thread.sleep(2000);
		PaymentRepo.ClickOnCCV(driver).sendKeys(CCVnm);
		Thread.sleep(1000);
		PaymentRepo.EnterName2(driver).sendKeys(Name2);
		Thread.sleep(1000);
		PaymentRepo.ClickPaybtn(driver).click();
		PaymentRepo.Closearrow(driver).click();
		 if(driver.getTitle().equals("review Page"))
		  {
			  driver.navigate().back();
			  
			  System.out.println("valid data");
		      System.out.println("");
		  }
		  }
	}
	@Then("user is navigated to PaymentPage")
	public void user_is_navigated_to_payment_page() 
	{
	    System.out.println("navigated to PaymentPage");
	}

}
