package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SearchBoxrepo;

public class SearchBoxDefns 
{
	WebDriver driver;
	@Given("I have browser opened and url is navigated")
	public void i_have_browser_opened_and_url_is_navigated() throws InterruptedException 
	{
		 WebDriverManager.edgedriver().setup();
		   driver=new EdgeDriver();
		   driver.manage().window().maximize();
		   driver.get("https://www.jiomart.com/");
		   Thread.sleep(2000);
	}

	@When("I search for product as {string}")
	public void i_search_for_product_as(String product) 
	{
		SearchBoxrepo.Searchbox(driver).click();
		SearchBoxrepo.ProductName(driver).sendKeys(product);
		SearchBoxrepo.SerchBt(driver).click();
		
	}

	@Then("Serch product range Low to high")
	public void serch_product_range_low_to_high() throws InterruptedException 
	{
		SearchBoxrepo.Range(driver).click();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("search-title"))
		   {
			   System.out.println("Search successful");
		   }
		else
		{
			System.out.println("search unsuccessful");
		}
		driver.close();
	   
	}

}


	

